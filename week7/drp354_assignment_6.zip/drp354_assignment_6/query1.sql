-- ################################################
-- #****CUSP Principle of urban informatic class**#
-- #-----Dimas R.Putro / drp354@nyu.edu-----------#
-- ################################################
-- Principle of urban informatics assignment 6

SELECT SUM(F.ff) AS 'nyc_ff_jan18' 
FROM fares_jan18 AS F
